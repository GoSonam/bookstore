# pacman-Game


<p align="center">
  <a href="https://ashish2030.github.io/gh-profile-readme-generator">
    <img alt="GitHub Profile Readme Generator" src="./src/images/mdg.png" width="60" />
  </a>
</p>
<h1 align="center">
  Pacman-Game
</h1>

<p align="center">
<a href="https://github.com/ashish2030/pacman-Game/blob/master/LICENSE" target="blank">
<img src="https://img.shields.io/github/license/ashish2030/github-profile-readme-generator?style=flat-square" alt="github-profile-readme-generator licence" />
</a>
<a href="https://github.com/ashish2030/pacman-Game/fork" target="blank">
<img src="https://img.shields.io/github/forks/ashish2030/github-profile-readme-generator?style=flat-square" alt="github-profile-readme-generator forks"/>
</a>
<a href="https://github.com/ashish2030/pacman-Game/stargazers" target="blank">
<img src="https://img.shields.io/github/stars/rahuldkjain/github-profile-readme-generator?style=flat-square" alt="github-profile-readme-generator stars"/>
</a>
<a href="https://github.com/ashish2030/pacman-Game/issues" target="blank">
<img src="https://img.shields.io/github/issues/rahuldkjain/github-profile-readme-generator?style=flat-square" alt="github-profile-readme-generator issues"/>
</a>
<a href="https://github.com/ashish2030/pacman-Game/pulls" target="blank">
<img src="https://img.shields.io/github/issues-pr/rahuldkjain/github-profile-readme-generator?style=flat-square" alt="github-profile-readme-generator pull-requests"/>
</a>
<a href="https://discord.gg/HHMs7Eg" target="blank">
<img src="https://img.shields.io/discord/735303195105951764?label=Join%20Community&logo=discord&style=flat-square" alt="join discord community of github profile readme generator"/>
</a>
</p>

<p align="center"><img src="./src/images/ezgif.com-gif-maker.gif" alt="github-profile-readme-generator gif" /></p>

<p align="center">
    <a href="https://github.com/Ashish2030/pacman-Game" target="blank">View Demo</a>
    ·
    <a href="https://github.com/ashish2030/pacman-Game/issues/new/choose">Report Bug</a>
    ·
    <a href="https://github.com/ashish2030/pacman-Game/issues/new/choose">Request Feature</a>
</p>


